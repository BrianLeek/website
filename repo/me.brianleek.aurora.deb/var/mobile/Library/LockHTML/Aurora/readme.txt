Thank you for downloading my widget!

FAQ:
 Q: How can I change the time format to 24 hours?
   A: Go into the "scripts" folder and open "custom.js" and find "if (hour > 12) {" and change it to "if (hour > 24) {".
 Q: How can I extend the length of the 2 lines?
   A: Go into the "css" folder and open "style.css" and find ".line1" and ".line2" and change the width to whatever you want for both of them.
 Q: How do I make the widget text bigger?
   A: Go into the "css" folder and open "style.css" and find "#time", "#date" and "#day-month" now change the "font-size" for each one to the size you want.

If you have any questions please feel free to contact me.