Thank you for downloading my widget!

FAQ:
 Q: How can I change the time format to 24 hours?
   A: Go into the "scripts" folder and open "custom.js" and find "if (hour > 12) {" and change it to "if (hour > 24) {".
 Q: How can I change the default font?
   A: Go into the "css" folder and open "style.css" and find "font-family:'BebasNeueRegular'" and change "BebasNeueRegular" to any font you want.
 Q: How do I remove the seconds from the time?
   A: Go into the "scripts" folder and open "custom.js" and find ":${seconds}" and remove it. 
 Q: How can I use a custom font that I downloaded?
   A: Upload your custom font to the "fonts" folder and go into the "css" folder and open "style.css" and find "@font-face" and updated it to your font info also don't forget to update the font-family in the body class.
      Example:
      
      @font-face{font-family:'Your Font Name';src:url(../fonts/Font-Name.ttf);font-weight:400;font-style:normal;

If you have any questions please feel free to contact me.